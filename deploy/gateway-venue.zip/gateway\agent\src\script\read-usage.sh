#!/bin/sh
# Read byte counters for a MAC's tc class (JSON output)
# Usage: read-usage.sh <mac>
# Output: {"bytesOut": N}  (tc reports sent bytes on egress class)

. "$(dirname "$0")/lib.sh"

MAC=$(normalize_mac "$1")
require_mac "$MAC"
require_cmd tc

CLASSID=$(grep -i "^${MAC}=" "$MAC_CLASS_MAP" 2>/dev/null | tail -1 | cut -d= -f2)
[ -z "$CLASSID" ] && CLASSID=$(mac_to_classid "$MAC")

# Parse 'Sent XXX bytes' from tc -s class show
stats=$(tc -s class show dev "$LAN_DEV" classid "1:${CLASSID}" 2>/dev/null)
bytes=$(echo "$stats" | grep -o 'Sent [0-9]* bytes' | head -1 | grep -o '[0-9]*')
[ -z "$bytes" ] && bytes=0

echo "{\"bytesOut\": $bytes}"
